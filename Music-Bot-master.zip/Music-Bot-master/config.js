exports.TOKEN = '';

exports.PREFIX = 'm!';

exports.GOOGLE_API_KEY = '';
